# -*- coding: utf-8 -*-
"""
健康卡联网平台 API 对接引擎

平台: https://jkkyljl.hnhfpc.gov.cn (湖南省健康卡医疗机构联网平台)

核心流程:
  1. openid → getToken → JWT
  2. JWT → newlist → 健康卡列表
  3. healthCardId → updateRpc(rpc=1) → 绕过人脸验证
  4. healthCardId → querybyidcardqyjg → 签约信息
  5. personId → queryqyxxall → 合同详情
  6. editqr → 签约确认 (STATUS 5→1)
"""
import json
import time
import base64
import logging
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Callable

import requests
import urllib3

urllib3.disable_warnings()
logger = logging.getLogger(__name__)

HC_BASE_URL = "https://jkkyljl.hnhfpc.gov.cn"


@dataclass
class HealthCard:
    health_card_id: str
    name: str
    id_card: str
    age: str = ""
    gender: str = ""
    rpc: str = ""
    relation: str = ""
    phone: str = ""

    @property
    def is_verified(self) -> bool:
        return self.rpc == "1"

    @property
    def age_category(self) -> str:
        try:
            a = int(self.age)
        except (ValueError, TypeError):
            return ""
        if a < 18:
            return "未成年"
        if a >= 60:
            return "老年人"
        return "成年人"


@dataclass
class HCContract:
    guid: str
    person_id: str
    health_card_id: str
    orgcode: str
    org_name: str = ""
    status: str = ""
    doctor: str = ""
    start_date: str = ""
    end_date: str = ""
    name: str = ""

    @property
    def is_pending(self) -> bool:
        return self.status == "5"

    @property
    def is_confirmable(self) -> bool:
        return self.status in ("5", "6")


@dataclass
class HCConfirmResult:
    success: bool
    name: str = ""
    health_card_id: str = ""
    error: str = ""
    elapsed: float = 0.0


class HealthCardClient:
    """健康卡联网平台 HTTP 客户端。"""

    def __init__(self, base_url: str = HC_BASE_URL):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.trust_env = False
        self.session.verify = False
        self.session.headers["User-Agent"] = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
        self.jwt_token: str = ""
        self.openid: str = ""
        self.connected: bool = False
        self._timeout = 30

    def _svc_url(self) -> str:
        return f"{self.base_url}/httpapi/services.ashx"

    def _jkxb_url(self) -> str:
        return f"{self.base_url}/httpapi/jkxbservice.ashx"

    def _jkxb_headers(self) -> dict:
        return {**self.session.headers, "token": self.jwt_token}

    def connect(self, openid: str) -> Tuple[bool, str]:
        self.openid = openid
        self.connected = False
        self.jwt_token = ""

        try:
            r = self.session.get(
                self._svc_url(),
                params={"ACTION": "getToken", "Openid": openid},
                timeout=self._timeout,
            )
            data = r.json()
            if not isinstance(data, dict):
                return False, "获取Token失败: 响应格式异常"
            if data.get("errno") != 0:
                return False, "获取Token失败: %s" % data.get("message", "未知错误")

            inner = data.get("data")
            token = inner.get("token") if isinstance(inner, dict) else None
            if not token:
                return False, "获取Token失败: 响应缺少 token 字段"
            self.jwt_token = token
            self.connected = True

            try:
                payload = self.jwt_token.split(".")[1]
                payload += "=" * (4 - len(payload) % 4)
                decoded = json.loads(base64.urlsafe_b64decode(payload))
                from datetime import datetime
                exp = datetime.fromtimestamp(decoded["exp"])
                return True, "连接成功 — Token有效期至 %s" % exp.strftime("%Y-%m-%d %H:%M")
            except Exception:
                return True, "连接成功"

        except requests.exceptions.ConnectionError:
            return False, "连接失败：无法连接服务器"
        except requests.exceptions.Timeout:
            return False, "连接超时：服务器响应过慢"
        except Exception as e:
            return False, "连接异常: %s" % str(e)

    def get_card_list(self) -> List[HealthCard]:
        if not self.connected:
            return []

        try:
            r = self.session.get(
                self._svc_url(),
                params={
                    "ACTION": "newlist",
                    "Openid": self.openid,
                    "token": self.jwt_token,
                },
                timeout=self._timeout,
            )
            data = r.json()
            if not isinstance(data, dict) or data.get("errno") != 0:
                logger.warning(
                    "获取卡列表失败: %s",
                    data.get("message") if isinstance(data, dict) else "响应格式异常",
                )
                return []

            raw_items = data.get("data", [])
            if not isinstance(raw_items, list):
                logger.warning("获取卡列表: data 字段非列表, 返回空")
                return []

            cards = []
            for item in raw_items:
                if not isinstance(item, dict):
                    continue
                cards.append(HealthCard(
                    health_card_id=item.get("healthCardId", ""),
                    name=item.get("name", ""),
                    id_card=item.get("idCard", ""),
                    age=item.get("age", ""),
                    gender=item.get("gender", ""),
                    rpc=item.get("rpc", ""),
                    relation=item.get("relation", ""),
                    phone=item.get("phone", ""),
                ))
            return cards
        except Exception as e:
            logger.error("获取卡列表异常: %s", e)
            return []

    def update_rpc(self, health_card_id: str) -> Tuple[bool, str]:
        if not self.connected:
            return False, "未连接"

        try:
            r = self.session.get(
                self._svc_url(),
                params={
                    "ACTION": "updateRpc",
                    "Openid": self.openid,
                    "token": self.jwt_token,
                    "healthCardId": health_card_id,
                    "rpc": "1",
                },
                timeout=self._timeout,
            )
            data = r.json()
            if not isinstance(data, dict):
                return False, "更新RPC失败: 响应格式异常"
            msg = data.get("message", "")
            errno = data.get("errno")
            # 成功判定优先用平台统一的 errno==0; 仅当响应没有 errno 字段时,
            # 才回退到 message 含"已完成"(防止把含 errno!=0 的错误响应误报成功).
            if errno == 0:
                return True, msg or "已完成"
            if errno is None and "已完成" in msg:
                return True, msg
            return False, msg or "更新RPC失败"
        except Exception as e:
            return False, str(e)

    def query_signing_info(self, health_card_id: str) -> Optional[dict]:
        if not self.connected:
            return None

        try:
            r = self.session.get(
                self._jkxb_url(),
                params={
                    "action": "querybyidcardqyjg",
                    "healthCardId": health_card_id,
                },
                headers=self._jkxb_headers(),
                timeout=self._timeout,
            )
            data = r.json()
            if not isinstance(data, dict) or data.get("errno") != 0:
                return None
            inner = data.get("data")
            if isinstance(inner, list) and inner:
                return inner[0] if isinstance(inner[0], dict) else None
            if isinstance(inner, dict):
                return inner
            return None
        except Exception as e:
            logger.error("查询签约信息异常: %s", e)
            return None

    def query_contracts(
        self, person_id: str, health_card_id: str
    ) -> List[HCContract]:
        if not self.connected:
            return []

        try:
            r = self.session.get(
                self._jkxb_url(),
                params={
                    "action": "queryqyxxall",
                    "personId": person_id,
                    "healthCardId": health_card_id,
                },
                headers=self._jkxb_headers(),
                timeout=self._timeout,
            )
            data = r.json()
            if data.get("errno") != 0:
                return []

            contracts = []
            for item in data.get("data", []):
                contracts.append(HCContract(
                    guid=item.get("guid", ""),
                    person_id=person_id,
                    health_card_id=health_card_id,
                    orgcode=item.get("jgbm", ""),
                    org_name=item.get("jgmc", ""),
                    status=str(item.get("qyzfbs", "")),
                    doctor=item.get("qyys", ""),
                    start_date=item.get("xyksrq", ""),
                    end_date=item.get("xyjsrq", ""),
                ))
            return contracts
        except Exception as e:
            logger.error("查询合同异常: %s", e)
            return []

    def confirm_one(self, contract: HCContract) -> HCConfirmResult:
        if not self.connected:
            return HCConfirmResult(False, error="未连接")

        t0 = time.time()
        try:
            r = self.session.get(
                self._jkxb_url(),
                params={
                    "action": "editqr",
                    "guid": contract.guid,
                    "b0105_13": contract.status or "5",
                    "status": "1",
                    "personid": contract.person_id,
                    "openid": self.openid,
                    "orgcode": contract.orgcode,
                    "healthCardId": contract.health_card_id,
                },
                headers=self._jkxb_headers(),
                timeout=self._timeout,
            )
            elapsed = time.time() - t0
            data = r.json()

            if data.get("errno") == 0:
                return HCConfirmResult(
                    True, name=contract.name,
                    health_card_id=contract.health_card_id,
                    elapsed=elapsed,
                )
            return HCConfirmResult(
                False, name=contract.name,
                health_card_id=contract.health_card_id,
                error=data.get("message", "") or data.get("data", ""),
                elapsed=elapsed,
            )
        except Exception as e:
            return HCConfirmResult(
                False, name=contract.name,
                health_card_id=contract.health_card_id,
                error=str(e), elapsed=time.time() - t0,
            )

    # ---- 居民申请签约 (insertJtysqy) ----

    def get_person_guid(self, health_card_id: str) -> Optional[str]:
        """Get the hex GUID (personId) for a patient from their healthCardId."""
        info = self.query_signing_info(health_card_id)
        if info:
            return info.get("GUID", "")
        return None

    def query_teams(self, orgcode: str, health_card_id: str = "") -> List[dict]:
        """List signing teams for an org via querygroup.

        平台要求带 ``healthCardId`` 授权上下文, 否则返回
        ``errno=1 卡列表中未读取到信息``。
        """
        if not self.connected:
            return []
        try:
            params = {"action": "querygroup", "orgcode": orgcode}
            if health_card_id:
                params["healthCardId"] = health_card_id
            r = self.session.get(
                self._jkxb_url(),
                params=params,
                headers=self._jkxb_headers(),
                timeout=self._timeout,
            )
            data = r.json()
            if data.get("errno") == 0:
                return data.get("data", [])
            return []
        except Exception as e:
            logger.error("查询团队异常: %s", e)
            return []

    def query_service_packages(
        self, orgcode: str, population_type: str = "", health_card_id: str = ""
    ) -> List[dict]:
        """List service packages for an org via queryservicepackge.

        平台要求带 ``healthCardId`` 授权上下文, 否则返回
        ``errno=1 卡列表中未读取到信息``。
        """
        if not self.connected:
            return []
        try:
            params = {
                "action": "queryservicepackge",
                "orgcode": orgcode,
                "b0110_02": "1",
            }
            if population_type:
                params["b0110_07"] = population_type
            if health_card_id:
                params["healthCardId"] = health_card_id
            r = self.session.get(
                self._jkxb_url(), params=params,
                headers=self._jkxb_headers(), timeout=self._timeout,
            )
            data = r.json()
            if data.get("errno") == 0:
                return data.get("data", [])
            return []
        except Exception as e:
            logger.error("查询服务包异常: %s", e)
            return []

    def create_resident_contract(
        self,
        person_id: str,
        health_card_id: str,
        name: str,
        gender: str,
        phone: str,
        orgcode: str,
        team_name: str,
        team_guid: str,
        doctor_name: str,
        package_names: str,
        package_guids: str,
        start_date: str,
        end_date: str,
        period_years: str = "3",
    ) -> Tuple[bool, str]:
        """Create a '居民申请' (status=6) contract via insertJtysqy.

        Dates must be YYYYMMDD format. Returns (success, message).
        """
        if not self.connected:
            return False, "未连接健康卡平台"

        form_data = {
            "ACTION": (None, "insertJtysqy"),
            "orgcode": (None, orgcode),
            "personid": (None, person_id),
            "xm": (None, name),
            "xb": (None, gender),
            "b0105_01": (None, "2"),
            "b0105_02": (None, phone),
            "b0105_03": (None, team_name),
            "b0105_03_guid": (None, team_guid),
            "b0105_04": (None, doctor_name),
            "b0105_05": (None, start_date),
            "b0105_06": (None, package_names),
            "b0105_06_guid": (None, package_guids),
            "b0105_08": (None, period_years),
            "b0105_07": (None, start_date),
            "b0105_09": (None, end_date),
            "b0105_10": (None, "0"),
            "b0105_11": (None, "0"),
            "b0105_12": (None, "0"),
            "b0105_13": (None, "6"),
            "openid": (None, self.openid),
            "healthCardId": (None, health_card_id),
        }

        try:
            r = self.session.post(
                "%s?token=%s" % (self._jkxb_url(), self.jwt_token),
                files=form_data,
                headers={
                    "token": self.jwt_token,
                    "Origin": "https://jkkgzh.hnhfpc.gov.cn",
                    "Referer": "https://jkkgzh.hnhfpc.gov.cn/",
                },
                timeout=self._timeout,
            )
            data = r.json()
            if data.get("errno") == 0:
                return True, "居民申请创建成功"
            detail = data.get("data", "")
            msg = data.get("message", "创建失败")
            if detail and isinstance(detail, str) and detail != msg:
                msg = "%s (%s)" % (msg, detail.strip())
            return False, msg
        except Exception as e:
            return False, "创建异常: %s" % str(e)

    def delete_contract(self, contract_guid: str, orgcode: str) -> Tuple[bool, str]:
        """Delete a pending contract via deletejtysqy."""
        if not self.connected:
            return False, "未连接"
        try:
            r = self.session.post(
                self._jkxb_url(),
                data={"ACTION": "deletejtysqy", "guid": contract_guid,
                      "orgcode": orgcode},
                headers=self._jkxb_headers(),
                timeout=self._timeout,
            )
            data = r.json()
            if data.get("errno") == 0:
                return True, "删除成功"
            return False, data.get("message", "删除失败")
        except Exception as e:
            return False, str(e)

    # ---- 健康卡注册 ----

    def register_health_card(
        self,
        wechatcode: str,
        id_card: str,
        name: str,
        phone: str = "",
        nation: str = "01",
        relation: str = "本人",
        verify_result: str = "",
        order_id: str = "",
    ) -> Tuple[bool, str]:
        """Register a new health card via jkkzc registration API.

        Requires a valid Wechatcode from the WeChat OAuth flow.
        For ages <18 or >=60, verifyResult can be empty (no face needed).
        Returns (success, message).
        """
        if not self.openid:
            return False, "OpenID未设置"

        try:
            r = requests.post(
                "https://jkkzc.hnhfpc.gov.cn/gzc/Wx_jmjkk/Handler.ashx?action=test",
                data={
                    "Openid": self.openid,
                    "idCard": id_card,
                    "name": name,
                    "nation": nation,
                    "relation": relation,
                    "phone": phone or "13800000000",
                    "verifyResult": verify_result,
                    "orderId": order_id,
                },
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                  "AppleWebKit/537.36 MicroMessenger/7.0.20",
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Wechatcode": wechatcode,
                    "Referer": "https://jkkzc.hnhfpc.gov.cn/gzc/Wx_jmjkk/"
                               "regist.html?Wechat_code=%s" % wechatcode,
                },
                cookies={
                    "token": self.jwt_token,
                    "Wechatcode": wechatcode,
                },
                verify=False,
                timeout=15,
            )
            body = r.text.strip()
            if body == "{}":
                return False, "注册失败(Wechatcode可能已过期或人脸验证被拒)"
            if not body:
                return False, "注册失败(空响应)"
            # 修复: 之前 errno!=0 / 非 JSON 都被乐观当作 "提交成功", 误导 UI.
            # 现在: 只接受明确的 errno==0 / success==True 作为成功.
            try:
                data = json.loads(body)
            except json.JSONDecodeError:
                return False, "注册失败 (非JSON响应): %s" % body[:160]
            if data.get("errno") == 0 or data.get("success") is True:
                return True, "健康卡注册成功"
            err = data.get("errmsg") or data.get("msg") or body[:160]
            return False, "注册失败: %s" % err
        except Exception as e:
            return False, "注册异常: %s" % str(e)

    def unbind_health_card(self, health_card_id: str) -> Tuple[bool, str]:
        """Unbind a health card via cancelunbind."""
        if not self.connected:
            return False, "未连接"
        try:
            r = self.session.get(
                "%s/httpapi/jkdaservice.ashx" % self.base_url,
                params={
                    "ACTION": "cancelunbind",
                    "healthCardId": health_card_id,
                    "token": self.jwt_token,
                },
                headers=self._jkxb_headers(),
                timeout=self._timeout,
            )
            data = r.json()
            if data.get("errno") == 0:
                return True, "解绑成功"
            return False, data.get("message", "解绑失败")
        except Exception as e:
            return False, str(e)

    # ---- 原有流程 ----

    def process_card(
        self,
        card: HealthCard,
        log_cb: Optional[Callable] = None,
    ) -> Optional[HCConfirmResult]:
        """Process a single health card: updateRpc → query → confirm."""

        def log(msg, tag=""):
            if log_cb:
                log_cb(msg, tag)

        if not card.is_verified:
            ok, msg = self.update_rpc(card.health_card_id)
            if ok:
                log("  设置人脸认证: %s" % msg, "ok")
                card.rpc = "1"
            else:
                log("  设置人脸认证失败: %s" % msg, "err")
                return HCConfirmResult(
                    False, name=card.name,
                    health_card_id=card.health_card_id,
                    error="设置人脸认证失败: %s" % msg,
                )

        info = self.query_signing_info(card.health_card_id)
        if not info:
            log("  无签约记录", "warn")
            return None

        person_id = info.get("GUID", "")
        status = info.get("CONTRACT_STATES", "")
        orgcode = info.get("gdjgcode", "")

        if str(status) not in ("5", "6"):
            status_names = {
                "0": "已签约", "1": "未签约",
                "5": "医生申请(待确认)", "6": "居民申请(待确认)",
            }
            log("  状态: %s (非待确认)" % status_names.get(str(status), status), "warn")
            return None

        contracts = self.query_contracts(person_id, card.health_card_id)
        pending = [c for c in contracts if c.is_confirmable]

        if not pending:
            log("  无待确认合同", "warn")
            return None

        last_result = None
        for contract in pending:
            contract.name = card.name
            contract.orgcode = contract.orgcode or orgcode
            log("  确认合同: %s" % contract.guid[:16], "info")
            result = self.confirm_one(contract)
            last_result = result

            if result.success:
                log("  >> 确认成功! (%.1f秒)" % result.elapsed, "ok")
            else:
                log("  >> 确认失败: %s" % result.error, "err")

        return last_result
